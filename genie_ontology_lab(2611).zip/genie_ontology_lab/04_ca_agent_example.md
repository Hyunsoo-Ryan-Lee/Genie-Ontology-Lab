## Filter: 온타리오 지역

Name:         온타리오 지역
SQL:          ca_customers.province = 'ON'
Synonyms:     온타리오, 온태리오, 온타리오주, 온타리오 지역, Ontario
Instructions: 사용자가 온타리오를 언급하면 고객 소재 주 코드 ON으로 필터링한다.

## Filter: 대량 주문

Name:         대량 주문
SQL:          ca_orders.quantity >= 500
Synonyms:     대량 주문, 큰 건, 대형 주문, 벌크 주문, bulk order
Instructions: 영업팀이 "큰 건", "대량 주문"이라고 하면 주문 1건의 수량이 500개 이상인 주문으로 필터링한다.