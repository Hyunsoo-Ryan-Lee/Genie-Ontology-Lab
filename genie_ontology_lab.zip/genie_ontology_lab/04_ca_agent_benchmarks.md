질문 : 2024 매출연도 Q1의 온타리오 판매수량은?

SQL 답변

SELECT SUM(o.quantity) AS units_sold
FROM labuser_._aibi_dashboards.ca_orders o
JOIN labuser_._aibi_dashboards.ca_customers c ON o.customerid = c.customerid
WHERE c.province = 'ON'
  AND o.orderdate BETWEEN '2024-02-01' AND '2024-04-30';