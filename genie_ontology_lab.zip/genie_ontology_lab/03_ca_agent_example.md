## Filter: 온타리오 지역

Name:         온타리오 지역
SQL:          ca_customers.province = 'ON'
Synonyms:     온타리오, 온태리오, 온타리오주, 온타리오 지역, Ontario
Instructions: 사용자가 온타리오를 언급하면 고객 소재 주 코드 ON으로 필터링한다.

## Measure: 평균 주문 금액

Name:         평균 주문 금액
SQL:          AVG(ca_orders.orderamt)
Synonyms:     평균 주문액, 평균 거래 금액, 평균 객단가, average order amount
Instructions: 주문 한 건당 평균 주문 금액을 계산하며 통화는 CAD를 사용한다.